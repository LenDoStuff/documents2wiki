# Property claim handover wiki

This workspace contains a reusable prompt, a fictional claim you can review, and the engineering design for the proposed application.

- **Create or update a claim wiki.** Give the agent the prompt and the claim’s documents with version IDs and numbered PDF pages. On a later addition, give it the new document and access to the current wiki and earlier sources so it can amend the affected entries. [Wiki creation prompt](prompts/purpose.md)
- **See what the handler gets.** The water-damage handover shows the four claim pages, the open pressure-test question, and how a signed addendum changes one inspection date. [Worked handover](architecture-wiki/examples/water-damage-handover.md) · [Fictional source pages](architecture-wiki/examples/water-damage-sources.md)
- **Build the application.** The handbook specifies how a completed PDF upload starts ingestion and how the handler can run a checklist against a published revision. Each claim’s generated files belong in its own data directory. [Engineering handbook](architecture-wiki/index.md) · [Claim folder layout](architecture-wiki/reference/claim-files-and-results.md#file-layout)
