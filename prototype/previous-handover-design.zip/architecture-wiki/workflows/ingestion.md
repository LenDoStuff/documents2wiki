---
type: Workflow
title: How a claim wiki is created and updated
description: How document arrival starts ingestion, how the first wiki is built, and how later evidence amends individual entries.
status: draft
sources:
  - id: D-01-v1-p1
    resource: ../examples/water-damage-sources.md#loss-notice-page-1
  - id: D-02-v1-p1
    resource: ../examples/water-damage-sources.md#work-order-page-1
  - id: D-03-v1-p2
    resource: ../examples/water-damage-sources.md#engineering-report-page-2
  - id: D-03-v1-p3
    resource: ../examples/water-damage-sources.md#engineering-report-page-3
  - id: D-04-v1-p1
    resource: ../examples/water-damage-sources.md#engineering-addendum-page-1
  - id: fruit
    resource: https://aclanthology.org/2022.naacl-main.269.pdf
  - id: wikibench
    resource: https://www.langchain.com/blog/evaluating-openwiki-with-wikibench
---

# How a claim wiki is created and updated

A completed PDF upload starts one ingestion run. For both the first build and
later additions, the application passes the contents of `prompts/purpose.md`
to the agent as its standing instructions. On the first build, the agent reads
the sources already on file. On a later upload it receives the new PDF with
numbered pages and can consult the current wiki and earlier sources. Python
stores the originals, applies the cited edits and publishes the revision.
[Wiki creation prompt](../../prompts/purpose.md)

[First document](#creating-the-first-wiki) · [Choosing pages](#which-page-should-change) · [Worked correction](#worked-update-from-r3-to-r4)

## From upload to publication

```mermaid
flowchart TD
    Add["Document added to the claim"] --> Source["Save the original and number its PDF pages"]
    Source --> Exists{"Does the claim have a published wiki?"}
    Exists -->|No| Build["Build the four claim pages once from the initial documents"]
    Build --> Cover["Check that each source and its material facts are accounted for"]
    Exists -->|Yes| Amend["Find affected entries and propose cited amendments"]
    Cover --> Save["Validate and publish one revision"]
    Amend --> Save
```

The browser submits the PDF on selection or drop. Once the full file arrives,
the [upload route](../reference/http-api.md#ingest-a-document) invokes
`ingest_document` for that claim. A claims platform can submit the same
request when it receives a document. A folder-based connector submits a
completed file from its intake folder and reuses the submission ID if the
same arrival is reported twice. Only incoming originals trigger this operation.

Python records the submission ID, version, digest, and receipt time. It keeps
the original under `originals/` and labels the text in physical PDF order,
including covers and blank pages, for example `[D-03-v1 | PDF page 3]`.
The agent can read a short PDF in full, open longer reports by page range,
search the claim wiki, and read a relevant entry or earlier source page.
An unreadable page is recorded as a gap.

The agent returns a cited source summary and the entries to add or amend.
It chooses which passages to inspect and can return an empty set of narrative
edits. Python lists the document in File Overview, links its summary from
the index, and applies the edits to the named sections. For a routine receipt,
the summary and its inventory and index links can be the entire update.

## Creating the first wiki

For an existing claim brought into the system, take the documents already on
file at the start of the import as one set. The agent writes one cited summary
per document and builds the four pages once. Before publication, account for
each source in the inventory and check its material dates, attributed opinions,
and outstanding requests against the four pages. Record gaps explicitly.
This coverage check addresses omissions during the first build.[^wikibench]

For a claim that starts empty, the first completed upload starts that build
immediately. PDFs arriving after the initial set are handled as amendments
against the latest published revision. The worked example follows documents
that arrived separately.

The first upload for `C-1042` is a loss notice. On page 1 the insured says
they noticed damp on 7 May and suspected roof entry after heavy rain. The
notice reached the handler on 8 May. The agent uses 7 May for the chronology,
attributes the roof theory to the insured on Claim Causation, and cites
*Loss notice, p. 1* in both places. File Overview records the receipt on
8 May. The action plan can say *No action requested in the notice*.[^D-01-v1-p1]

Python starts the four claim pages from Markdown templates. At `r1`, the wiki
index links those pages and the first summary, `documents/D-01-v1.md`. Its
citations point back to the original loss notice.
[Claim folder layout](../reference/claim-files-and-results.md#file-layout)

## Which page should change?

For a later addition, use the index and search for the event, person, or open
action across the four claim pages. Open matching passages and amend each
entry the evidence changes. Before proposing new wording, read the cited
original page and check what it actually supports, including who said it and
how certain they were.[^fruit] The signed work order, for example, places
the coupling replacement on **5 May**, even though the
work order arrived on **9 May**.[^D-02-v1-p1]

| Claim page | What belongs here | Example |
| --- | --- | --- |
| **Claim Chronology** | Events in occurrence order, with approximate or unknown dates labelled. | Insert the 5 May repair before the 7 May observation.[^D-02-v1-p1][^D-01-v1-p1] |
| **Claim Causation** | Attributed observations and possible explanations. Keep competing accounts visible. | Add the engineer's possible coupling leak alongside the insured's suspicion about the roof.[^D-03-v1-p3][^D-01-v1-p1] |
| **Claims Handler Action Plan** | Requested or suggested work and its documented progress. | Record the engineer's pressure-test recommendation. Cite a result if it arrives later.[^D-03-v1-p3] |
| **File Overview** | The document inventory and a short synopsis of material developments. | Add the report to the inventory and describe its opinion as provisional.[^D-03-v1-p3] |

In the engineering report, the opinion and the recommendation both appear on
page 3. A causation entry and an action-plan entry can cite the same pair.

```json
{"document_version_id": "D-03-v1", "page": 3}
```

The agent can add a citation to an existing entry when a new source
corroborates it. On a correction, search for the old value and other mentions
of the event. If two accounts disagree and neither corrects the other, show
both accounts with their sources. [How the citation is rendered](../reference/evidence-and-citations.md#a-citation-in-okf).

## Worked update from r3 to r4

At `r3` the chronology gives **12 May** for the site inspection, citing
page 2 of the engineering report. A signed addendum received on 21 May
explicitly changes the inspection date to **13 May**. Its page 1 is the
source for the new date.[^D-03-v1-p2][^D-04-v1-p1]

An example edit from the ingestion agent follows. `replace` quotes the
existing Markdown line under the named heading. `text` supplies the new
wording. The addendum supports 13 May and the report supports the account
of what was originally recorded. Python appends a footnote for each cited page.

```json
{
  "page_id": "chronology",
  "heading": "Events",
  "replace": "- 12 May — Engineer's site inspection.[^D-03-v1-p2]",
  "text": "- 13 May — Engineer's site inspection. The signed addendum corrects the 12 May date in the original report.",
  "citations": [
    {"document_version_id": "D-04-v1", "page": 1},
    {"document_version_id": "D-03-v1", "page": 2}
  ]
}
```

For a new entry, the agent can request an insertion under the heading,
next to an existing line if order matters. For a replacement Python
requires exactly one match in that section. If the text has moved or the
target is ambiguous, reread the current section before applying the edit.
The heading and existing wording are enough to locate the change.

The publisher also adds the addendum to the inventory and writes its summary.
The addendum carries forward the engineer's opinion. The causation entry and
test recommendation continue to cite the report's page 3. The handler can
reopen the earlier `r3` run and see the original date as it was recorded at
handover.[^D-03-v1-p3][^D-04-v1-p1]

## Validating and publishing a revision

Check each edit against the four allowed page names and their headings.
For the summary and each factual edit, check the document version against the
candidate inventory and the page against the PDF's page count. The agent can
retain an existing citation. To add a citation, it must select a page it was
shown. If an edit requires fresh evidence from an older report, give it that
numbered page as well. Generate the OKF footnote and original-file link from
the accepted pair. These checks establish that the reference resolves.
For example, the engineer's recommendation on page 3 supports a pending
action. Recording a completed pressure test would require a page giving its result.

Use one writer per claim and check the proposal's base revision before applying
it. If another revision was published, prepare the edits against that revision.
Stage the complete `claim.json` and wiki tree on the same filesystem, then
rename the completed directory to publish it. A failed write leaves the
last complete revision available.

Scope submission IDs to the claim. Check the ID under the claim's writer lock
before starting the agent. Persist the ID, source digest, and supplied receipt
metadata with the revision so a matching retry returns the published result.
A separate receipt of identical bytes can reuse the stored PDF and page text. Test the addendum
twice with the same submission ID. Expect one `r4`, one corrected timeline
entry, and a link that opens page 1 of the addendum. Compare the unaffected
pages byte for byte. [Handler's view of the correction](../examples/water-damage-handover.md#a-correction-arrives).

[^D-01-v1-p1]: [Loss notice, p. 1](../examples/water-damage-sources.md#loss-notice-page-1).
[^D-02-v1-p1]: [Contractor work order, p. 1](../examples/water-damage-sources.md#work-order-page-1).
[^D-03-v1-p2]: [Engineering report, p. 2](../examples/water-damage-sources.md#engineering-report-page-2).
[^D-03-v1-p3]: [Engineering report, p. 3](../examples/water-damage-sources.md#engineering-report-page-3).
[^D-04-v1-p1]: [Engineering addendum, p. 1](../examples/water-damage-sources.md#engineering-addendum-page-1).
[^fruit]: [FRUIT, section 4.3 and Appendix A on edit format and supporting evidence](https://aclanthology.org/2022.naacl-main.269.pdf).
[^wikibench]: [LangChain's WikiBench comparison of coverage in initial codebase wikis](https://www.langchain.com/blog/evaluating-openwiki-with-wikibench).

[Project home](../index.md) · [Ingestion request](../reference/http-api.md#ingest-a-document) · [Azure model client](../reference/azure-model-client.md) · [Evidence and citations](../reference/evidence-and-citations.md)
