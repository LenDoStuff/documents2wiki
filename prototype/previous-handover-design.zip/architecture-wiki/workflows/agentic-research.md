---
type: Workflow
title: Agentic research
description: How one Foundry agent searches a claim revision, checks original PDF pages, and returns a cited checklist.
status: draft
sources:
  - id: ms-agenticrag-paper
    resource: https://www.microsoft.com/en-us/research/publication/agenticrag-agentic-retrieval-for-enterprise-knowledge-bases/
    title: "AgenticRAG: Agentic Retrieval for Enterprise Knowledge Bases"
  - id: ms-agenticrag-method
    resource: https://arxiv.org/html/2605.05538
    title: AgenticRAG method and agentic loop algorithm
  - id: ms-agentic-rag
    resource: https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/rag/rag-agentic
  - id: foundry-agent
    resource: https://learn.microsoft.com/en-us/agent-framework/integrations/by-component/model-providers/microsoft-foundry
  - id: D-03-v1-p3
    resource: ../examples/water-damage-sources.md#engineering-report-page-3
---

# Agentic research

A handler asks *Is a pressure-test result on file?* The first hit is the
engineer's recommendation to run the test. The agent must read the page,
then look for a document recording the result. [Read the engineering report, p. 3](../examples/water-damage-sources.md#engineering-report-page-3).

The proposed checklist runner follows Microsoft's May 2026 paper
*AgenticRAG: Agentic Retrieval for Enterprise Knowledge Bases*. At each turn
one model chooses a retrieval tool or returns an answer. It can use what it
just read to change its next search. We use Microsoft Agent Framework with a
Foundry model, search the files in one claim revision, and cite physical PDF
pages. The paper uses an enterprise search backend and opens windows of
document lines.[^ms-agenticrag-paper][^ms-agenticrag-method][^foundry-agent]

## Checklist workflow

```mermaid
flowchart TD
    accTitle: Agentic research on a claim checklist
    accDescr: The Foundry agent can search across files, find within a document, or open a page. Each result informs the next turn. Answers go to the handler after a citation check.
    Input["Pin checklist<br/>and claim revision"] --> Agent{"Foundry agent<br/>chooses"}
    Agent --> Search["search<br/>Discover candidate files"]
    Agent --> Find["find<br/>Locate a passage in one file"]
    Agent --> Open["open<br/>Read the original page"]
    Search --> Review["Return results to the agent<br/>Summarize if context fills"]
    Find --> Review
    Open --> Review
    Review -->|Budget available| Agent
    Review -->|Research limit reached| Verify["Check PDF citations<br/>and mark gaps"]
    Agent -->|Ready to answer| Verify
    Verify --> Save["Handler reviews<br/>ordered answers"]
    classDef action fill:#eaf4fc,stroke:#6488a8,color:#15334c
    classDef decision fill:#195780,stroke:#195780,color:#fff
    classDef review fill:#e6f3ed,stroke:#608d78,color:#193f32
    class Search,Find,Open action
    class Agent decision
    class Verify,Save review
```

1. **Pin the file.** `run_checklist` in `app/research.py` loads the displayed
   revision's inventory and wiki index. One Agent Framework `Agent` receives
   that context and the ordered question IDs and text in a fresh session.
   The server binds its three read-only functions to that claim and revision.
   [Foundry model connection](../reference/azure-model-client.md).
2. **Choose the next read.** The agent can `search` with several phrasings,
   `find` terms inside one candidate document, or `open` a known page
   directly. Each result goes back to the same session. A wiki entry can
   supply a lead. Open the original for a material finding, look for competing
   accounts or later evidence in the revision, and reuse opened pages across
   questions. [Tool inputs and results](../reference/claim-files-and-results.md#research-tools).
3. **Decide whether to continue.** The paper caps the loop at 15 iterations
   by default and calls `summarize` when the conversation reaches its context
   threshold. Use 15 research turns as the starting ceiling for the whole
   checklist. If the context fills first, keep findings by question, contrary
   evidence, open leads and the source pages that support them. Trim other
   tool text, then resume. Python keeps the opened-page record and usage
   counters across summaries. It checks the remaining tool calls, tokens
   and time before dispatch and reserves capacity to write and verify
   the final answer.[^ms-agenticrag-method][^ms-agentic-rag]
4. **Check and hand over.** When the agent is ready or the research limit is
   reached, finish from the available evidence. For each finding, check that
   the cited page belongs to this revision, was opened successfully, and
   supports the wording at the stated certainty. Narrow unsupported wording
   or record a gap. Use `not_found` only after checking the plausible files.
   An unreadable relevant page or an interrupted search leaves that item
   `incomplete_search`. Keep finished rows. Save the input in `checklist.json`
   and the results, revision, usage and stop reason in `answers.json`.
   The handler sees one row per original
   question, in order, and can open each source before making the triage call.
   [Answer fields and statuses](../reference/claim-files-and-results.md#answer-statuses).

## Worked trace at r3

For claim `C-1042`, the pinned inventory contains a loss notice, a signed
work order and an engineering report. Here is one possible run for the
pressure-test question. [File at handover](../examples/water-damage-handover.md#the-file-the-handler-opens).

| Agent action | What comes back and what it changes |
| --- | --- |
| `search(["pressure test", "supply pipe test result"])` | The engineering report appears under both phrasings. The merged hit identifies `D-03-v1` and points to p. 3. |
| `find("D-03-v1", ["pressure test", "measurement", "result"])` | The report mentions a pressure test on p. 3. The matching passage gives the agent a place to read in context. |
| `open("D-03-v1", 3)` | The engineer recommends a test to distinguish possible sources of the water. This page supports reporting the recommendation. The result is still an open question.[^D-03-v1-p3] |
| `search(["pressure reading", "test certificate"])`, then check the remaining originals | A test might be recorded under different wording. The agent opens the remaining report pages, the loss notice and the work order. That accounts for all three files at `r3`. None records a result. [Fictional source documents](../examples/water-damage-sources.md). |

**Completed row — `not_found`.** “The engineer recommended a pressure test.
No result was found in the three documents at `r3`.” Cite `D-03-v1`, p. 3
for the recommendation. The gap is the completed test report or its
measurements.[^D-03-v1-p3]

**If a limit interrupts the last step — `incomplete_search`.** Keep the
verified recommendation and name the pages still unchecked. The handler
can distinguish missing evidence in a reviewed file from work still to do.
[Checklist request and response](../reference/http-api.md#run-a-checklist).

For the next question, *Did the contractor's work cause the damage?*, the
agent can reuse those pages. The work order establishes who replaced the
coupling. The engineer considered a coupling leak possible, and the insured
suspected roof entry. Those sources support a `partial` answer on causation.
[Compare the three cited accounts](../examples/water-damage-handover.md#example-checklist-at-r3).

[^ms-agenticrag-paper]: [Microsoft Research publication, May 2026](https://www.microsoft.com/en-us/research/publication/agenticrag-agentic-retrieval-for-enterprise-knowledge-bases/).
[^ms-agenticrag-method]: [Suresh et al., sections 3.2–3.4 and Algorithm 1](https://arxiv.org/html/2605.05538).
[^ms-agentic-rag]: [Microsoft Azure Architecture Center guidance on controlling the retrieval loop](https://learn.microsoft.com/en-us/azure/architecture/ai-ml/guide/rag/rag-agentic).
[^foundry-agent]: [Microsoft Foundry model provider for Agent Framework](https://learn.microsoft.com/en-us/agent-framework/integrations/by-component/model-providers/microsoft-foundry).
[^D-03-v1-p3]: [Engineering report, p. 3, opinion and recommendation](../examples/water-damage-sources.md#engineering-report-page-3).

[Project home](../index.md) · [Worked checklist](../examples/water-damage-handover.md#example-checklist-at-r3)
