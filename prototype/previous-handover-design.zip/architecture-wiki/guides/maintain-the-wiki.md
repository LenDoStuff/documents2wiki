---
type: How-to Guide
title: Update the project wiki
description: Where a change belongs, how to preserve evidence links, and which documentation patterns the project uses.
status: draft
sources:
  - id: diataxis
    resource: https://diataxis.fr/start-here/
  - id: langgraph-example
    resource: https://docs.langchain.com/oss/python/langgraph/quickstart
  - id: arc42-runtime
    resource: https://docs.arc42.org/section-6/
  - id: arc42-decisions
    resource: https://docs.arc42.org/section-9/
---

# Update the project wiki

1. **Edit the file that owns the change.** The ingestion agent gets its
   instructions from `prompts/purpose.md` at the project root. In the handbook,
   keep the project scope in the brief, ingestion and checklist behavior in
   `workflows/`, and the fictional claim and its sources in `examples/`.
   `architecture/` covers components and design decisions, `reference/`
   defines file and API contracts, and `guides/` holds procedures.
   [Wiki creation prompt](../../prompts/purpose.md)
2. **Keep the demo state visible.** Put a capability on the project home as
   available once readers can actually use it. Record proposed behavior and
   open questions in the brief. On the worked case, distinguish the documents
   available at handover from later corrections.
3. **Check an interface change end to end.** Keep HTTP examples, stored result
   fields, and the HTML display labels aligned. Verify the fixture expectation
   and distinguish an illustrative contract from one already implemented.
   [HTTP examples](../reference/http-api.md) · [Acceptance checks](build-and-test.md#acceptance-checks).
4. **Check navigation and provenance.** Reach the changed page from the home
   index and follow its next link. Preserve document versions and source-page
   links. For a changed finding, open the cited page and compare the wording
   with the original. Check that the OKF footnote label matches the source
   entry for that page.

## Why these pages are organized this way

Diátaxis distinguishes learning a skill, completing a task, looking up a
detail, and understanding a design. These needs explain the separate handover
walkthrough, review guide, reference, and architecture pages.[^diataxis]

LangGraph introduces its agent workflow through one calculator example and
links readers to deeper material. Here, one fictional claim carries the reader
from a signed work order through a missing test result and a correction.[^langgraph-example]

arc42 describes runtime behavior through selected scenarios and records
important decisions with their rationale. Here the two scenarios are document
arrival and checklist research. The storage decision has a separate page with
conditions for reconsidering it.[^arc42-runtime][^arc42-decisions]

[^diataxis]: [Diátaxis in five minutes](https://diataxis.fr/start-here/).
[^langgraph-example]: [LangGraph quickstart](https://docs.langchain.com/oss/python/langgraph/quickstart).
[^arc42-runtime]: [arc42 runtime view](https://docs.arc42.org/section-6/).
[^arc42-decisions]: [arc42 architecture decisions](https://docs.arc42.org/section-9/).

[Project home](../index.md) · [Project brief](../project-brief.md)
