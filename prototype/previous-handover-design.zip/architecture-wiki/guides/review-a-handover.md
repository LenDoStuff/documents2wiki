---
type: How-to Guide
title: Review a handover and give feedback
description: Check a finding against its source and leave a comment someone can act on.
status: draft
---

# Review a handover and give feedback

Use this guide when you want to tell the project team whether a checklist
answer is useful for triage. The worked handover can be reviewed now in
Markdown. A note alongside the wiki is enough for this first review.

1. **Identify what was available.** Note the claim and revision. In the
   fictional handover, `C-1042` at `r3` includes the loss notice, the work
   order, and the engineering report. The addendum belongs to a later revision.
   [Open the handover](../examples/water-damage-handover.md#example-checklist-at-r3).
2. **Choose a question that could change your next step.** Read the answer,
   then open its citation. Check that it lands on the named document and PDF
   page. Compare the named party, date, and certainty with the author's words. For the pipe case, compare what the
   contractor signed with what the engineer actually observed.
   [Work order, p. 1](../examples/water-damage-sources.md#work-order-page-1) · [Engineering report, p. 3](../examples/water-damage-sources.md#engineering-report-page-3).
3. **Check how a gap is described.** Identify the missing document or result
   and whether the search was completed. For example, a recommendation to test
   the pipe is evidence of a request. A test result would answer a different
   question. [Answer status definitions](../reference/claim-files-and-results.md#answer-statuses).
4. **Record the feedback.** Identify the wiki page and revision, or the run and
   checklist question. Say what you could use, what you would change, and
   which source page supports the comment. A useful note might read, “On the
   cause question, keep the word *possible*. The engineer qualifies the finding
   on page 3 of the report.” The triage decision stays with the handler.

## When the live runner is ready

Give the handler the prepared claim in the HTML page and let them enter a
fresh checklist. Observe whether they can open the cited page and find the
supporting words without help. If they have to hunt across a dense page,
record the document, page, and question. If a developer needs to
reproduce a finding, capture the claim revision, run ID, and question ID.
[First end-to-end acceptance checks](build-and-test.md#acceptance-checks).

[Project home](../index.md) · [Project brief](../project-brief.md)
