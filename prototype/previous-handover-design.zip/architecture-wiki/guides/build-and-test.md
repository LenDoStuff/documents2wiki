---
type: Implementation Guide
title: Build and test the first handover
description: Implementation order, local setup targets, and acceptance checks for the standalone Python service.
status: draft
sources:
  - id: fastapi-upload
    resource: https://fastapi.tiangolo.com/tutorial/request-files/
  - id: fastapi-test
    resource: https://fastapi.tiangolo.com/tutorial/testing/
---

# Build and test the first handover

This guide describes the planned application and its acceptance checks. The
commands below apply once the Python package and tests exist.

## Build order

1. **Prepare the PDFs and page reader.** Use the four fictional records to
   make one PDF per document under `fixtures/water-damage/`. Give the engineer's
   report a cover page, the inspection on page 2, and both the opinion and
   recommendation on page 3. Seed a temporary claim with the first three PDFs.
   Check that the work order opens on page 1 and the report on pages 2 and 3.
   [Source records](../examples/water-damage-sources.md).
2. **Implement ingestion and publication.** Connect a completed document
   addition to `ingest_document`. Load `prompts/purpose.md` as the agent’s
   instructions. Supply the numbered PDF, a way to find affected entries, and
   access to earlier source pages. Apply its cited
   amendments after checking the targets and page references. Exercise the
   first build, a later addition, a replay, and an interrupted write.
   [First revision and worked update](../workflows/ingestion.md#creating-the-first-wiki).
3. **Run one checklist end to end.** Bind `search`, `find` and `open` to
   `r3`. Use one Agent Framework agent with the Foundry connector. Feed each
   tool result into the next turn and save the checked answers in question
   order. [Follow the pressure-test trace](../workflows/agentic-research.md#worked-trace-at-r3).
4. **Expose the API and HTML page.** Start with a prepared claim, a wiki
   viewer, a document picker or drop area, one-question-per-line input, and
   a results table with source and feedback links. Adding a PDF in the browser
   submits the same upload request exercised by the Python test client.
   Confirm any pre-existing external route names before freezing the wire API.

## Local development target

Declare FastAPI, Uvicorn, `python-multipart`, `agent-framework-core`,
`agent-framework-foundry`, `azure-ai-projects`, and `azure-identity` in
`pyproject.toml` and include a PDF reader that exposes physical page order.
The upload endpoint uses multipart parsing. The proposed
`dev` extra adds pytest and HTTPX for FastAPI's test client.[^fastapi-upload][^fastapi-test]

Package `app/` with its static assets and the shared ingestion prompt. Pin a
compatible dependency set when the first live model call and local tool
invocation have passed.

When the package exists, use these commands from the repository root on Windows.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m pytest
```

The normal test suite uses a temporary data directory and a scripted model.
For a live run, configure the following in the server process and sign in
with an Azure identity that can invoke the chosen deployment. The last
command serves the same-origin HTML and API locally.

```powershell
$env:FOUNDRY_PROJECT_ENDPOINT = "https://<account>.services.ai.azure.com/api/projects/<project>"
$env:FOUNDRY_MODEL = "<deployment-name>"
$env:CLAIMS_DATA_DIR = ".\data\claims"
.\.venv\Scripts\python.exe -m uvicorn app.api:app --reload
```

Ingest the first three fixture files in receipt order, then open
`http://127.0.0.1:8000/`. Keep the addendum for the revision test.
[Azure client configuration](../reference/azure-model-client.md) · [Ingestion request](../reference/http-api.md#ingest-a-document).

## Acceptance checks

| Exercise | Pass condition |
| --- | --- |
| Add the loss notice through the browser, then exercise the same upload on a fresh claim through HTTP | The completed upload starts ingestion automatically. Each fresh claim publishes one first revision with the loss notice listed once and a summary citing p. 1. |
| Initialize a separate empty wiki from a handover that already contains the first three PDFs | One initial revision contains three cited summaries and the four claim pages. Check the 5 May repair, the 7 May observation, the 12 May inspection, and the outstanding pressure test against the source pages. |
| Add the signed addendum to the sequential fixture at `r3` | The single addition publishes `r4` and amends the existing inspection entry once. The 13 May date links to the addendum on p. 1. The original 12 May record is traceable to the report on p. 2. Read both pages to verify the wording. |
| Send “Who replaced the coupling?” and “What was the pressure-test result?” through the HTML page and the HTTP test client | Both runs preserve order, cite the work order on p. 1 for Contractor A, and report the missing result at `r3`. The second citation opens the recommendation on p. 3 of the engineering report. Compare statuses and cited pages across clients. |
| Ask a new question about when the damp patch was first noticed | The run finds the insured's 7 May observation on p. 1 of the loss notice. |
| Search with two phrasings for the pressure test, then find `PRESSURE TEST` inside `D-03-v1` | Search merges the repeated p. 3 hit. Find returns the recommendation on p. 3. The citation passes verification only after the agent opens that original page. |
| Reopen a saved `r3` run after ingesting the signed addendum | The `r3` chronology shows 12 May with the report on p. 2. A fresh `r4` lookup returns 13 May with the addendum on p. 1. A request for the addendum against `r3` returns `404`. |
| Return a citation to p. 4 of the three-page engineering report | Ingestion rejects the edit. A direct source-page request returns `404`. A checklist answer must cite a page the agent actually opened. |
| Compare causation and action-plan pages before and after the date-only addendum | Both pages are byte-identical across `r3` and `r4` and their citations still open the report on p. 3. |
| Add a receipt that supplies only filing metadata | The inventory and cited document summary account for the receipt. The chronology, causation narrative, and action plan match the preceding revision. |
| Replay an upload or interrupt publication | A retry returns the completed submission or finishes the interrupted one. No duplicate event or partially readable revision appears. |
| Force a tool-call cap before the report is examined | The run retains answered items, marks unfinished ones `incomplete_search`, and records the budget stop. |
| Trigger context summarization after opening the report | The next turn can reuse the p. 3 reference and the pending test-result question. The opened-page record and cumulative usage survive summarization. |

Run the contract and revision tests offline. Before the handler session, run
the two-question checklist once against Azure and open both sources from
the browser. Check that the first link opens the signed work order and that
the second opens the engineer's recommendation with its qualification intact.

[^fastapi-upload]: [FastAPI file uploads and multipart dependency](https://fastapi.tiangolo.com/tutorial/request-files/).
[^fastapi-test]: [FastAPI testing with HTTPX and pytest](https://fastapi.tiangolo.com/tutorial/testing/).

[Project home](../index.md) · [Repository layout](../architecture/repository-layout.md) · [HTTP example](../reference/http-api.md#run-a-checklist) · [Worked handover](../examples/water-damage-handover.md)
