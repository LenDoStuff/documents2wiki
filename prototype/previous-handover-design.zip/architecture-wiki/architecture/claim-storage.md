---
type: Architecture Decision
title: Use JSON files for the proof of concept
description: The storage decision, its consequences, and the conditions for revisiting relational or vector search.
status: draft
sources:
  - id: mysql-fulltext
    resource: https://dev.mysql.com/doc/refman/8.4/en/innodb-fulltext-index.html
    title: MySQL 8.4 Reference Manual on InnoDB full-text indexes
  - id: mysql-vector
    resource: https://dev.mysql.com/doc/refman/9.7/en/vector-functions.html
    title: MySQL 9.7 Reference Manual on vector functions
---

# Use JSON files for the proof of concept

**Selected for the PoC.** Store structured state in JSON, publish claim pages in
OKF Markdown, and keep the original files in the claim folder. Implement the
retriever as Python functions over one revision. Microsoft Agent Framework
orchestrates their use during a checklist run.

## Why this fits the first demo

The pilot asks one handler to review one fictional claim and try their own
checklist. A file-backed revision can be inspected, copied for a session, and
reopened with the same document versions and PDF page references. It lets the team change the
checklist and sample claim independently. `store.py` serializes publication
within a claim. `evidence.py` can search the numbered pages in memory and
return each hit with its title, page number, and excerpt.
[Proposed file layout](../reference/claim-files-and-results.md#file-layout).

## When to revisit the decision

Reconsider storage if independent processes need to publish to the same
claim or if loading a revision exceeds the demo's time or memory budget.
Reconsider retrieval if representative handler questions repeatedly miss the
right source pages. Record the question, expected document and page, actual hits, and time to
find the answer. Those observations identify whether the issue is file access,
search vocabulary, or the agent's use of an otherwise relevant hit.

## What would move to MySQL?

If shared storage becomes necessary, move document manifests, numbered page
text, revisions, and checklist runs behind `store.py`. Original
files can remain in separate object storage. Typed columns can index claim
IDs, document versions, and dates. InnoDB full-text indexes can search
PDF page text with `MATCH() AGAINST()`.[^mysql-fulltext]

Preserve each document-version and page reference during migration. Search
within the caller's authorized revision and apply source permissions to the
derived wiki pages.
Then the three research tools and the application's HTTP contract can remain
usable by the same clients.

## If semantic search is needed

Evaluate keyword retrieval on a known set of claim questions, including
paraphrases and competing explanations. Measure whether the source pages needed
for an answer appear among the results, along with latency and cost per run.

If terminology causes misses, try embeddings for text within the authorized
pages of one claim and merge the semantic and keyword results. If scanning
becomes too slow, an indexed vector backend can return the same document
versions and page numbers to clients. Expose a revision to research when its
index entries are ready.

Native vector search depends on the deployment. Oracle's MySQL 9.7 manual
limits the SQL `DISTANCE()` function to HeatWave on OCI and MySQL AI. Check the
target edition before selecting an in-database vector strategy.[^mysql-vector]

[^mysql-fulltext]: [InnoDB full-text indexes, MySQL 8.4 Reference Manual](https://dev.mysql.com/doc/refman/8.4/en/innodb-fulltext-index.html).
[^mysql-vector]: [Vector functions, MySQL 9.7 Reference Manual](https://dev.mysql.com/doc/refman/9.7/en/vector-functions.html).

[Project home](../index.md) · [System overview](system-overview.md) · [Evidence and citations](../reference/evidence-and-citations.md)
