---
type: Architecture Overview
title: System overview
description: Runtime boundaries and design decisions for a standalone FastAPI application using Microsoft Agent Framework and Azure Foundry.
status: draft
sources:
  - id: fastapi
    resource: https://fastapi.tiangolo.com/features/
  - id: foundry
    resource: https://learn.microsoft.com/en-us/agent-framework/integrations/by-component/model-providers/microsoft-foundry
---

# System overview

Run one Python application. FastAPI serves the HTML interface and accepts HTTP
requests. Two application operations do the work. `ingest_document` publishes
a claim revision. `run_checklist` reads a revision and publishes a research
run. A future claims platform can call the same operations through HTTP.

## Components

```mermaid
flowchart TD
    Browser[HTML and JavaScript] -->|HTTP| API[FastAPI]
    Caller[Future claims platform] -.->|Same HTTP API| API
    API -->|Document added| Ingest[ingestion.py]
    API --> Research[research.py / Agent Framework]
    Ingest -->|Cited summary and entry amendments| Model[foundry.py / Azure project model]
    Research -->|Plan and synthesize| Model
    Ingest -->|Locate affected entries and read earlier evidence| Evidence
    Research -->|Read-only tools| Evidence[evidence.py]
    Evidence -->|Read pinned revision| Store[store.py / claim files]
    Ingest -->|Publish revision| Store
    Research -->|Save checklist run| Store
```

## Design decisions

| Decision | Reason and consequence |
| --- | --- |
| One FastAPI application serves static HTML, CSS, JavaScript, and a JSON API | The browser can use ordinary same-origin requests. FastAPI can describe typed request and response models in OpenAPI for a second client.[^fastapi] |
| Start one ingestion run automatically on document arrival | At first import the agent builds the four pages and checks coverage of the available sources. For a later PDF it locates the affected entries and proposes a cited amendment to each. Python applies the edits and publishes one revision. |
| Cite the document version and physical PDF page | The agent compares each amended fact with the original page. Python checks that the reference resolves and gives the handler a link to that page. [Citation contract](../reference/evidence-and-citations.md). |
| Use one Agent Framework agent per checklist run | The agent can change its search after seeing a result. The application supplies its tools, budget, and claim revision. The Foundry provider supports application-owned tools and project-backed inference.[^foundry] |
| Implement retrieval as ordinary Python functions | One fictional claim fits in memory. Searching its JSON and Markdown makes it easy to inspect the PDF pages a tool returned. Missed evidence and latency are measurable reasons to revisit the choice. |
| Keep Azure and storage details behind the application boundary | The frontend and future clients exchange claim IDs, revision IDs, answers, and evidence links. Changing model deployment or storage can preserve that interface. |

## Two runtime paths

- **Document arrival.** A completed upload starts `ingest_document` in the same
  request. The agent can search the claim and open earlier evidence as needed.
  It returns a source summary and any entries to add or amend. Ingestion
  validates the targets, renders source links, and asks `store.py` to publish.
  [Ingestion workflow](../workflows/ingestion.md).
- **Checklist submission.** The browser submits questions and the revision
  displayed on screen. At each turn the Foundry agent can search across that
  revision, find passages within a document, open an original page, or return
  its answers. `research.py` enforces the run budget and checks the citations
  before saving the run. [Checklist workflow](../workflows/agentic-research.md#checklist-workflow).

## What a published revision contains

A revision contains the inventory, page-labelled source text, document
summaries, and four claim pages visible together at publication. Serve or export that
revision as one OKF bundle per claim. Its `index.md` links to **Claim Chronology**,
**Claim Causation**, **Claims Handler Action Plan**, **File Overview**, and the
individual document summaries.

Publish the revision when its wiki and cited original pages are available. Research
uses the revision the handler opened. The answers identify that revision and
its document inventory so the handler can tell which files were considered.

An original records what its author wrote. A wiki entry preserves that
attribution and its qualifiers. Research can discover relevant evidence on
any source page in the revision, including material the wiki omits. A saved
answer links back to the PDF so the handler can inspect its wording.

[^fastapi]: [FastAPI features and OpenAPI support](https://fastapi.tiangolo.com/features/).
[^foundry]: [Microsoft Foundry model provider for Agent Framework](https://learn.microsoft.com/en-us/agent-framework/integrations/by-component/model-providers/microsoft-foundry).

[Project home](../index.md) · [Repository layout](repository-layout.md) · [HTTP API](../reference/http-api.md) · [Storage decision](claim-storage.md)
