---
type: Repository Design
title: Repository layout
description: Proposed files, dependencies, and ownership boundaries in the standalone Python PoC.
status: draft
---

# Repository layout

The workspace contains the wiki creation prompt, this handbook, and a worked
claim. The first implementation would add the files below. [Workspace guide](../../README.md)

```text
pyproject.toml                 runtime dependencies and development extras
app/
  __init__.py
  api.py                       FastAPI entry point, wire models, dependency wiring
  foundry.py                   Azure credential, project client, model connector
  ingestion.py                 label PDF pages, summarize, apply cited edits, publish
  research.py                  agent, run budget, answer validation and synthesis
  evidence.py                  search original pages, find passages, open wiki or PDF pages
  store.py                     originals, revision manifests, runs, feedback
  static/
    index.html
    app.js
    styles.css
fixtures/
  water-damage/                source PDFs in receipt order and expected page citations
tests/                         offline contract, retrieval, and revision tests
```

Use the shared `prompts/purpose.md` for the ingestion agent on both the first
build and later uploads. Each run supplies the claim-specific evidence. Store
generated claim folders under `CLAIMS_DATA_DIR` and use a temporary directory
for test runs. [Wiki creation prompt](../../prompts/purpose.md) · [Claim folder layout](../reference/claim-files-and-results.md#file-layout)

## Which module owns a change?

| Change | Owner | Boundary |
| --- | --- | --- |
| Add a request field or integrate another app | `api.py` | Validate the wire model, call an operation, and serialize the result. Return public IDs and evidence links. |
| Change project endpoint or model deployment | `foundry.py` | Construct the backend model connector at startup. Ingestion and research receive it as a dependency. |
| Change how a document updates the wiki | `ingestion.py` | Start the agent on arrival with the numbered source and access to the current claim. Validate its proposed entry amendments and page references, render OKF, and pass a complete revision to the store. |
| Change how questions are planned or when a search stops | `research.py` | Construct a run-scoped agent, enforce budgets, check each material answer against its cited PDF pages, and save one ordered answer per question. |
| Change how a source page is found | `evidence.py` | Search only the selected revision. Return original document versions, PDF page numbers, and excerpts to the agent. |
| Change where claim state lives | `store.py` | Read or publish revisions and write isolated run artifacts. Keep caller-facing IDs stable. |

## Frontend and integration

`index.html` lays out the wiki, document picker or drop area, checklist input,
and results. `app.js` opens the prepared claim, submits a selected or dropped
PDF immediately, and displays the revision returned by the API. It sends the
handler's questions in order and displays each answer, gap, and source link.
Render answer text as text and wiki Markdown with raw HTML disabled. Resolve
wiki links through the revision's page manifest and source citations through
the document-page endpoint. Submit feedback with the page or question being reviewed.

Serve the page and its assets from the Python application. A future platform
can replace the browser as a caller. Both clients use the same typed HTTP
contract, while the Azure credential and runtime data directory stay on the
server. An app factory in `api.py` can accept the data directory and model
factory before the application lifespan starts. Offline HTTP tests supply a
temporary directory and a scripted model through that seam.

[Project home](../index.md) · [System overview](system-overview.md) · [API contract](../reference/http-api.md) · [Build and test](../guides/build-and-test.md)
