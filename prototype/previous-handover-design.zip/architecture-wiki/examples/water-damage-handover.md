---
type: Walkthrough
title: A water-damage claim
description: A worked subrogation checklist for property damage after a contractor worked on a pipe.
status: draft
sources:
  - id: D-01-v1-p1
    resource: water-damage-sources.md#loss-notice-page-1
  - id: D-02-v1-p1
    resource: water-damage-sources.md#work-order-page-1
  - id: D-03-v1-p2
    resource: water-damage-sources.md#engineering-report-page-2
  - id: D-03-v1-p3
    resource: water-damage-sources.md#engineering-report-page-3
  - id: D-04-v1-p1
    resource: water-damage-sources.md#engineering-addendum-page-1
---

# A water-damage claim

Take over fictional claim `C-1042`. Your task is to check which contractor
worked on the pipe, how much the file establishes about the cause, and which
result is still missing. You can complete this walkthrough by opening the
linked source pages. The three example questions stand in for the checklist
a handler will bring to the live demo.

## The file the handler opens

Start at revision `r3`. Its inventory includes the loss notice received on
8 May (`r1`), a work order received on 9 May (`r2`), and the engineer's report
received on 18 May (`r3`). These are the four claim-page summaries at handover.

| Wiki page | What you see at handover |
| --- | --- |
| **Claim Chronology** | The contractor worked on 5 May, the insured noticed the wet patch on 7 May, and the engineering report records a 12 May inspection.[^D-02-v1-p1][^D-01-v1-p1][^D-03-v1-p2] |
| **Claim Causation** | The insured suspected roof entry. The engineer considered a coupling leak possible and could not establish the source of the water.[^D-01-v1-p1][^D-03-v1-p3] |
| **Claims Handler Action Plan** | The engineer recommended a pressure test. Completion is an open question.[^D-03-v1-p3] |
| **File Overview** | The loss notice, work order, and engineering report are available. The cause remains open. |

## Example checklist at r3

1. **Who worked on the pipe, and when?** Find the name and signed work date
   on the work order. This item is **Answered** by the record of Contractor A
   replacing the coupling on 5 May.[^D-02-v1-p1] [Open the work order](water-damage-sources.md#work-order-page-1).
2. **What connects that work to the water damage?** Compare the engineer's
   opinion with the insured's account. The evidence is **Partial**. The engineer
   identifies the coupling as one possible source. The visual inspection left
   the route of entry unresolved, and the insured suspected roof entry after
   heavy rain.[^D-02-v1-p1][^D-03-v1-p3][^D-01-v1-p1]
   [Read the engineering report, p. 3](water-damage-sources.md#engineering-report-page-3) · [Read the loss notice](water-damage-sources.md#loss-notice-page-1).
3. **Is a pressure-test result on file?** Check what the engineer requested.
   The file at `r3` contains a recommendation and no result, so the item is
   marked **Not found in this file**.[^D-03-v1-p3]
   [Open the recommendation](water-damage-sources.md#engineering-report-page-3) · [Trace the agent's search](../workflows/agentic-research.md#worked-trace-at-r3).

You now have evidence of who performed the work, a qualified opinion about
the leak, and an outstanding test. The decision on subrogation stays with you.

## A correction arrives

Adding the signed addendum on 21 May starts ingestion. The agent locates the
existing inspection entry and amends it once. At `r4` the entry gives **13 May**
on the authority of the addendum, p. 1, and identifies the earlier **12 May**
record in the engineering report, p. 2.[^D-04-v1-p1][^D-03-v1-p2]
File Overview lists the addendum and links its summary. The engineer's opinion
and test recommendation both cite page 3 of the original report.[^D-03-v1-p3]
[Original inspection record](water-damage-sources.md#engineering-report-page-2) · [Signed correction](water-damage-sources.md#engineering-addendum-page-1).

The original handover remains tied to `r3`. To evaluate whether its answers
would be useful in your work, pick one row and record what you would change.
[Review the handover and give feedback](../guides/review-a-handover.md).

[^D-01-v1-p1]: [Loss notice, insured's account, p. 1](water-damage-sources.md#loss-notice-page-1).
[^D-02-v1-p1]: [Contractor work order, scope and date, p. 1](water-damage-sources.md#work-order-page-1).
[^D-03-v1-p2]: [Engineering report, inspection record, p. 2](water-damage-sources.md#engineering-report-page-2).
[^D-03-v1-p3]: [Engineering report, p. 3, opinion and recommendation](water-damage-sources.md#engineering-report-page-3).
[^D-04-v1-p1]: [Engineering addendum, corrected date, p. 1](water-damage-sources.md#engineering-addendum-page-1).

[Project home](../index.md) · [All fictional source documents](water-damage-sources.md)
