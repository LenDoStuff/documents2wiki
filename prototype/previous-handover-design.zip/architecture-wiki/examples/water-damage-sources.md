---
type: Demonstration Evidence
title: Fictional claim documents
description: Page transcriptions of the four fictional documents used to verify the water-damage walkthrough.
status: draft
---

# Fictional claim documents

These short records were written for the demo of claim `C-1042`. The checklist
at revision `r3` covers the first three records. The addendum appears later,
at `r4`. These Markdown transcriptions let readers open the cited pages in
this handbook. The planned demo will use four PDFs with the same page
numbers. Page numbers refer to positions in the PDF from the first sheet.

## Loss notice

`D-01-v1`. Received 8 May. Statement by the insured.

### Loss notice page 1

> On 7 May I noticed a wet patch on the kitchen ceiling after heavy rain.
> I thought water might have come in through the roof. I did not see where
> the water first entered.

## Contractor's work order

`D-02-v1`. Received 9 May. Signed work order.

### Work order page 1

> Contractor A replaced the cold-water supply coupling in the upstairs utility
> room on 5 May. The customer signed for completion of the work that afternoon.

## Engineering report

`D-03-v1`. Received 18 May. The report has three pages. Its inspection
record is on page 2. The opinion and recommendation share page 3.

### Engineering report page 2

> I recorded the inspection on 12 May. I examined the kitchen
> ceiling and the utility room above it. (Page 2)

### Engineering report page 3

**Opinion**

> A leak at the utility-room supply coupling is one possible explanation for
> the pattern of moisture. My visual inspection did not establish the source
> of the water. (Page 3, opinion)

**Recommendation**

> I recommend a pressure test of the supply pipe and connection to help
> distinguish this possibility from another route of water entry.
> (Page 3, recommendations)

## Engineering addendum

`D-04-v1`. Received 21 May after the first checklist run. Signed correction.

### Engineering addendum page 1

> My site diary confirms the inspection was on 13 May. Please correct the
> inspection date in my original report. My observations and opinion are
> unchanged.

[Project home](../index.md) · [Return to the worked checklist](water-damage-handover.md#example-checklist-at-r3)
