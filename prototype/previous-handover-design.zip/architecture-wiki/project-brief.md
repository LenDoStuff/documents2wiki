---
type: Project Brief
title: Subrogation triage proof of concept
description: The handover problem, agreed demo scope, success criteria, and remaining product questions.
status: draft
---

# Subrogation triage proof of concept

A handler inherits a property claim after a contractor worked on a pipe. They
need to understand what the file says about the work, what connects it to the
damage, and what remains unverified. The PoC will test whether a claim wiki and
cited answers to the handler's own checklist help them make that triage call.

The first delivery is a standalone Python backend and a plain HTML frontend.
FastAPI provides the integration boundary. Both the browser and a future
claims platform can submit documents, request a checklist run, and follow
source links against a selected revision. [System architecture](architecture/system-overview.md).

## The handler's session

| Agreed scope | What the handler should be able to do |
| --- | --- |
| Prepared fictional claim | Open File Overview, Claim Chronology, Claim Causation, the Claims Handler Action Plan, and the document summaries. |
| New evidence | Add a PDF to start ingestion automatically. Open the resulting revision and follow an amended entry to the original page that justifies the change. |
| Self-service checklist | Bring a new checklist, check the questions in their original order, and run it without assistance. |
| Evidence and gaps | Read a short answer per item, click through to the cited page of the original PDF, and identify missing or competing evidence. |
| Human decision | Make the subrogation triage call and leave feedback on the specific answer or wiki page used. |

## What can be reviewed now?

The Markdown walkthrough contains three illustrative checklist questions and
four fictional documents. Three documents belong to the first handover and a
later addendum demonstrates a correction. The live runner and feedback screen
are design targets. [Open the worked handover](examples/water-damage-handover.md).

## Open questions

- The handler will supply the real checklist later. One question per line is
  the proposed first input method. Whether a file import is needed remains open.
- The two backend operations are defined. Confirm a future platform's route
  names and wire schemas before treating the example HTTP mappings as final.
  [Proposed HTTP API](reference/http-api.md).

## First feedback session

For the live pilot, observe whether the handler can run their own questions
independently, find the supporting words on the cited PDF page, and identify
what evidence is still needed. Record any point that required help. The same
evidence check can be tried on the static handover today.
[Review a handover and give feedback](guides/review-a-handover.md).

[Project home](index.md) · [System overview](architecture/system-overview.md)
