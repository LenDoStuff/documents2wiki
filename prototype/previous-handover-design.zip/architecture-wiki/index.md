---
okf_version: "0.2"
---

# Claims handover engineering handbook

The proposed application maintains one wiki per property claim and helps the handler check whether the file supports pursuing subrogation. The handler makes the decision. The design and fictional handover are available here. [Project brief](project-brief.md)

## Workflows

| Trigger | What happens in the proposed application | Read more |
| --- | --- | --- |
| A PDF finishes uploading | One ingestion agent builds the initial wiki or amends the entries affected by the new evidence. Each material change cites the original PDF page. | [Wiki creation prompt](../prompts/purpose.md) · [Ingestion workflow](workflows/ingestion.md) |
| The handler submits a checklist | One Microsoft Agent Framework agent searches the selected claim revision, opens original pages, and returns cited answers and evidence gaps in question order. | [Agentic research workflow](workflows/agentic-research.md#checklist-workflow) |

## Worked claim

Open the water-damage handover at revision `r3`. Compare the engineer’s inspection date with the signed addendum to see what changes at `r4`. [Worked handover](examples/water-damage-handover.md) · [Source documents](examples/water-damage-sources.md) · [Handler review guide](guides/review-a-handover.md)

## Engineering reference

| Task | Open |
| --- | --- |
| Understand the components and the storage decision | [System overview](architecture/system-overview.md) · [Claim storage](architecture/claim-storage.md) |
| Implement and test the first handover | [Proposed application layout](architecture/repository-layout.md) · [Build and test](guides/build-and-test.md) |
| Inspect how the wiki is stored and how a citation opens a PDF page | [Claim folder layout and results](reference/claim-files-and-results.md#file-layout) · [Evidence and citations](reference/evidence-and-citations.md) |
| Connect the API or the Azure model | [HTTP API](reference/http-api.md) · [Azure model client](reference/azure-model-client.md) |
| Update this handbook | [Maintenance guide](guides/maintain-the-wiki.md) |
