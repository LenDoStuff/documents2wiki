---
type: Integration Reference
title: Azure project and model client
description: How the standalone Python app obtains its model client from a Foundry project and supplies it to Agent Framework.
status: draft
sources:
  - id: azure-project
    resource: https://learn.microsoft.com/en-us/python/api/azure-ai-projects/azure.ai.projects.aio.aiprojectclient?view=azure-python
  - id: foundry-provider
    resource: https://learn.microsoft.com/en-us/agent-framework/integrations/by-component/model-providers/microsoft-foundry
  - id: foundry-source
    resource: https://github.com/microsoft/agent-framework/blob/main/python/packages/foundry/agent_framework_foundry/_chat_client.py
  - id: fastapi-lifespan
    resource: https://fastapi.tiangolo.com/advanced/events/
---

# Azure project and model client

`app/foundry.py` owns the Azure integration. This design interprets the project
“get client” flow as the async Azure AI Projects SDK's
`AIProjectClient.get_openai_client()`. That method returns an authenticated
async client for the project. Agent Framework's `FoundryChatClient` accepts
the existing project client and invokes that method internally.[^azure-project][^foundry-source]

## Configuration

| Setting | Meaning |
| --- | --- |
| `FOUNDRY_PROJECT_ENDPOINT` | The full project endpoint, such as `https://<account>.services.ai.azure.com/api/projects/<project>`. |
| `FOUNDRY_MODEL` | The model deployment name in that project. Choose a deployment that supports the tool calls and structured output used by this app.[^foundry-provider] |
| Azure identity | The backend process needs an identity authorized for project model inference. The example uses the async Azure Identity credential chain. |

## How the clients fit together

The following proposed adapter can be entered from FastAPI's application
lifespan. It creates a single model connector per application event loop.
The app owns the project client and credential it supplies to the connector
and closes each resource at shutdown.[^foundry-source][^fastapi-lifespan]

```python
from contextlib import asynccontextmanager
from os import environ

from agent_framework.foundry import FoundryChatClient
from azure.ai.projects.aio import AIProjectClient
from azure.identity.aio import DefaultAzureCredential


@asynccontextmanager
async def open_model():
    async with DefaultAzureCredential() as credential:
        async with AIProjectClient(
            endpoint=environ["FOUNDRY_PROJECT_ENDPOINT"],
            credential=credential,
        ) as project:
            model = FoundryChatClient(
                project_client=project,
                model=environ["FOUNDRY_MODEL"],
            )
            try:
                yield model
            finally:
                await model.close()
```

The ingestion agent uses the connector to read numbered source text, consult
relevant entries, and return a cited summary and any amendments in one run. Research
creates an `Agent` for each checklist run and supplies the three local tools
bound to that run's revision. In this example, `open_source` is registered
under the tool name `open`. Individual runs keep separate
messages, tools, and budgets while sharing the model connector on the same
event loop.[^foundry-provider]

```python
from agent_framework import Agent


def make_checklist_agent(model, search, find, open_source):
    return Agent(
        client=model,
        name="ChecklistResearch",
        instructions=(
            "Answer the checklist in order. Open original PDF pages for material "
            "findings. Preserve each author's qualifications, cite the document "
            "version and page, and identify gaps."
        ),
        tools=[search, find, open_source],
    )
```

The project endpoint, deployment, and identity are server configuration. The
browser receives application JSON. Offline tests inject a scripted substitute
at this boundary. A separate live smoke test verifies the team's actual
Azure project, deployment, credential, and installed SDK versions.

[^azure-project]: [Azure AI Projects async client and get_openai_client](https://learn.microsoft.com/en-us/python/api/azure-ai-projects/azure.ai.projects.aio.aiprojectclient?view=azure-python).
[^foundry-provider]: [Microsoft Foundry model provider for Agent Framework](https://learn.microsoft.com/en-us/agent-framework/integrations/by-component/model-providers/microsoft-foundry).
[^foundry-source]: [Microsoft's Python connector implementation](https://github.com/microsoft/agent-framework/blob/main/python/packages/foundry/agent_framework_foundry/_chat_client.py).
[^fastapi-lifespan]: [FastAPI application lifespan](https://fastapi.tiangolo.com/advanced/events/).

[Project home](../index.md) · [Research workflow](../workflows/agentic-research.md) · [Build and test](../guides/build-and-test.md)
