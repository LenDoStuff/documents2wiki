---
type: Data Model
title: Evidence and citations
description: How a document version and physical PDF page become a clickable citation in the wiki and checklist.
status: draft
sources:
  - id: okf-spec
    resource: https://github.com/GoogleCloudPlatform/knowledge-catalog/blob/main/okf/SPEC.md
    title: Open Knowledge Format v0.2 specification
---

# Evidence and citations

A handler should be able to click *Engineering report, p. 3* and read the
engineer's own words. The citation has two fields. `document_version_id`
identifies the immutable uploaded file. `page` is the one-based physical page
in that PDF, including any cover sheets. The same pair works in a wiki entry,
a checklist answer, and the source viewer.

```json
{"document_version_id": "D-03-v1", "page": 3}
```

## Where the page number comes from

Python reads the PDF in file order, records its page count, and keeps the
text grouped by page. A short document can go into one model call with the
page boundaries marked. When a longer document is read in parts, each part
carries its original page numbers. The agent selects from those supplied
labels. A printed folio can differ from the PDF viewer's page position.

`store.py` keeps the original and the revision's manifest. `evidence.py` looks
up the pair within the selected claim and revision. The checklist agent calls
`open("D-03-v1", 3)`, which delegates to `open_evidence`. The browser uses the same
lookup to obtain the title and an original-file URL ending in `#page=3`.
When validating citations, reject an unknown document version, a noninteger
page, or a page outside the original file. [HTTP source routes](http-api.md#read-the-wiki-open-a-source-and-give-feedback).

## A citation in OKF

For an OKF concept page, the footnote label matches an entry in the page's
`sources` list. Python derives that label from the pair, so two findings
on the same source page can share it. The API carries the two fields.
The footnote link also works in an exported claim folder.[^okf-spec]

This is an excerpt from a generated `revisions/r3/wiki/causation.md`.

```markdown
---
type: Claim Causation
title: Claim Causation
sources:
  - id: D-03-v1-p3
    resource: ../../../originals/D-03-v1.pdf#page=3
---

The engineer considered a coupling leak possible. The visual inspection did
not establish the source of the water.[^D-03-v1-p3]

[^D-03-v1-p3]: [Engineering report, p. 3](../../../originals/D-03-v1.pdf#page=3).
```

## What a page citation establishes

The engineering report puts its opinion and pressure-test recommendation on
the same page. The causation and action-plan entries can both point there.
A checklist answer about the cause must preserve the engineer's *possible*.
An answer about the test must distinguish the recommendation from a result.
Opening the cited page lets the agent and handler check both readings.
[Engineering report, p. 3 in the fixture](../examples/water-damage-sources.md#engineering-report-page-3).

For the PoC, keep IDs for document versions and derive each citation from the
page number. Defer separate identifiers for assertions, paragraphs, and wiki
rows. Revisit finer citations if handlers reach the right page and still
struggle to locate the evidence on it.

[^okf-spec]: [Open Knowledge Format v0.2, section 5.1 on provenance and attribution](https://github.com/GoogleCloudPlatform/knowledge-catalog/blob/main/okf/SPEC.md#51-provenance-sources).

[Project home](../index.md) · [Claim files and checklist results](claim-files-and-results.md) · [Ingestion workflow](../workflows/ingestion.md)
