---
type: Interface Reference
title: HTTP API and integration
description: Proposed FastAPI mappings, example payloads, and outcomes for document ingestion and checklist research.
status: draft
---

# HTTP API and integration

The two application operations are `ingest_document` and `run_checklist`.
The HTTP paths and field names here are **proposed mappings**. An external
platform's existing HTTP specification has yet to be supplied. If it prescribes
different names, adapt the FastAPI routes and wire models at that boundary.

All routes in the tables are relative to `/api/v1/claims/{claim_id}`. For the
small PoC, a command request waits for a bounded operation to finish and its
result to be saved. A read of a saved run uses the existing result.

## Ingest a document

| Method and path | Input | Successful result |
| --- | --- | --- |
| `POST /documents` | Multipart form with the demo PDF in `file`, `submission_id`, and optional `received_at`. Use the upload time when receipt time is omitted. | `201` with the document version ID and newly published revision. A matching retry returns the original result with `200`. |

Adding the PDF is the trigger. On selection or drop, the browser sends the
upload. Once the complete file is received, the route immediately calls
`ingest_document` and returns after publication. A platform integration
uses the same route and submission ID for a redelivery of that arrival.
[First build and later amendments](../workflows/ingestion.md#from-upload-to-publication).

First ingestion can initialize a claim folder. Scope submission IDs to the
claim. Reusing an ID for different content or conflicting supplied metadata
returns `409`. Publish once the wiki, original PDF, and numbered source text
are available together. This is the example response for the third fictional document.

```json
{
  "claim_id": "C-1042",
  "document_version_id": "D-03-v1",
  "revision": "r3"
}
```

## Run a checklist

| Method and path | Input | Successful result |
| --- | --- | --- |
| `POST /checklist-runs` | JSON containing the displayed `revision` and a nonempty, ordered `questions` array. Question IDs must be unique and text must be nonblank. | `201` with the saved run, its revision, and one answer per input item. |
| `GET /checklist-runs/{run_id}` | A saved run ID belonging to the claim. | `200` with the saved result and its original revision. |

The HTML page and a future client can submit this same request. The server
applies the configured research budget.

```json
{
  "revision": "r3",
  "questions": [
    {"question_id": "q1", "text": "Who replaced the coupling?"},
    {"question_id": "q2", "text": "What was the pressure-test result?"}
  ]
}
```

In the example below, page 3 of the engineering report supports the answer
about the recommendation. The inventory at `r3` defines which documents the
agent could search for the result. Usage values are illustrative.

```json
{
  "claim_id": "C-1042",
  "revision": "r3",
  "run_id": "run-001",
  "stop_reason": "completed",
  "usage": {"tool_calls": 5, "model_tokens": 1600, "elapsed_ms": 4200},
  "answers": [
    {
      "question_id": "q1",
      "text": "Who replaced the coupling?",
      "status": "answered",
      "answer": "Contractor A replaced the coupling on 5 May.",
      "citations": [{"document_version_id": "D-02-v1", "page": 1}],
      "gap": null
    },
    {
      "question_id": "q2",
      "text": "What was the pressure-test result?",
      "status": "not_found",
      "answer": "The engineer recommended a pressure test. No result was found in the three documents at r3.",
      "citations": [{"document_version_id": "D-03-v1", "page": 3}],
      "gap": "The completed test report or its measurements."
    }
  ]
}
```

If a limit ends the run early, save completed findings and mark unchecked or
unfinished items `incomplete_search`. A saved run can therefore have a
successful HTTP response and an incomplete investigation. Unknown revisions
or run IDs return `404`. Invalid request bodies return `422`.
[Answer status reference](claim-files-and-results.md#answer-statuses).

## Read the wiki, open a source, and give feedback

| Method and path | Purpose |
| --- | --- |
| `GET /wiki` | Return the latest published revision and its available page IDs, titles, and revision-specific links. |
| `GET /revisions/{revision}/wiki/{page_id}` | Return the wiki page's Markdown and its document-version/page citations for the pinned revision. |
| `GET /revisions/{revision}/documents/{document_version_id}/pages/{page}` | Validate the page and return the document title, page number, extracted page text, and URL to open the original at that page. |
| `GET /revisions/{revision}/documents/{document_version_id}/original` | Serve the immutable PDF belonging to the selected claim and revision. The browser follows the supplied `#page=N` fragment. |
| `POST /feedback` | Save a note against a revision and page or a run and question. Return `201` and the feedback ID. |

For the engineering opinion at `r3`, request
`/api/v1/claims/C-1042/revisions/r3/documents/D-03-v1/pages/3`.
Its original-file URL ends in `/documents/D-03-v1/original#page=3`. The
browser uses that fragment to navigate inside the PDF. The server resolves
both reads against the selected claim and revision. An unknown document,
a PDF page outside its range, or a document first received after that
revision returns `404`. A saved run keeps its original revision in the link.

[Project home](../index.md) · [Repository layout](../architecture/repository-layout.md) · [Claim files](claim-files-and-results.md) · [Build and test](../guides/build-and-test.md)
