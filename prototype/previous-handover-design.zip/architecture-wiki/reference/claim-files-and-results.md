---
type: Interface Reference
title: Claim files and checklist results
description: Proposed file layout, research tools, answer fields, and status meanings for the JSON-based PoC.
status: draft
---

# Claim files and checklist results

This is the proposed contract for `app/store.py` and `app/evidence.py`.
All paths below are relative to one claim under `CLAIMS_DATA_DIR`.
A **revision** identifies the documents and wiki pages read together. A
**run** identifies one checklist answered against that revision.

## File layout

At handover, claim `C-1042` has three PDFs. The tree shows its files for revision `r3`. [Worked handover](../examples/water-damage-handover.md#the-file-the-handler-opens)

```text
C-1042/
  originals/
    D-01-v1.pdf
    D-02-v1.pdf
    D-03-v1.pdf
  revisions/r3/
    claim.json
    wiki/
      index.md
      file-overview.md
      chronology.md
      causation.md
      action-plan.md
      documents/
        D-01-v1.md
        D-02-v1.md
        D-03-v1.md
  runs/run-001/
    checklist.json
    answers.json
  feedback.json
```

Within `wiki/`, `index.md` links to the four claim pages and every summary under `documents/`. Each summary uses the document version ID as its filename and cites pages in the matching original PDF.

| Path | Contents |
| --- | --- |
| `originals/` | Immutable uploaded PDFs, keyed by document version. The title shown to the handler comes from the inventory. |
| `revisions/r3/claim.json` | Document versions and titles, original paths and digests, submission and receipt metadata, PDF page counts, and extracted text grouped by page. |
| `revisions/r3/wiki/` | An OKF Markdown index, the four claim pages, and document summaries for this revision. |
| `runs/run-001/checklist.json` | The handler's original question text and order, with a stable ID for each item. |
| `runs/run-001/answers.json` | The claim revision, one row per input question, tool usage, and the reason the run stopped. |
| `feedback.json` | Comments associated with a wiki page and revision or with a checklist run and question. |

Ingestion stages each full revision on the same filesystem and exposes it by
renaming the completed directory. Each research request has a separate run
ID. Save completed run artifacts together before returning the HTTP result.
Serialize writes to shared claim files such as feedback, and use a temporary
file followed by replacement so a reader sees a complete JSON document.

## Research tools

The Foundry agent sees three retrieval functions. `research.py` binds them
to one claim and revision before the first turn. A document reference is its
immutable version ID. A wiki reference is a page ID from the revision's index
or links. [Checklist workflow and paper](../workflows/agentic-research.md).

| Agent tool | What `evidence.py` does | What comes back |
| --- | --- | --- |
| `search(queries)` | Run `search_claim(query)` over the original PDF text for each of 1–5 phrasings. Rank pages by distinct normalized terms matched, breaking ties by document version and page number. | Up to 10 matching documents per phrasing, with titles, page numbers and short excerpts. Merge results by document version and remove repeated page hits. |
| `find(ref, patterns)` | Scan one original document for case-insensitive substrings, across its numbered pages. | Up to two distinct matching passages per pattern, each with a physical page number. An empty match list lets the agent try other wording. |
| `open(ref, page?)` | For an original, call `open_evidence(document_version_id, page)` (default p. 1). For a wiki page or summary, call `read_page(page_id)` with the wiki reference alone. | An original returns the full numbered page text, title and PDF link. A wiki read returns Markdown, outgoing links and citation leads. Only a successful original-page read counts toward answer verification. |

Python rejects unknown references and out-of-range pages and reports unreadable
pages separately from empty matches. `research.py` records every successfully
opened original as a document-version/page pair, the same pair used by the
checklist and source viewer. The controller's `summarize` step compacts session
history and preserves these references.

## Answer statuses

Each answer row carries `question_id`, the original `text`, a machine-readable
`status`, the short `answer`, a `citations` array, and a nullable `gap`.
Each citation has a `document_version_id` and integer `page`, for example
`{"document_version_id": "D-03-v1", "page": 3}`. Use an empty array when
no supporting page was found. Use the same status values on disk and on the
wire. The HTML displays the corresponding labels. The enclosing run includes
`claim_id`, `revision`, `run_id`, `usage`, and `stop_reason`.
[Full request and response](http-api.md#run-a-checklist).

| Wire value | Display label | Meaning |
| --- | --- | --- |
| `answered` | Answered | The cited pages support the answer at its stated level of certainty. |
| `partial` | Partial | Some evidence answers part of the question. Name what remains unresolved. |
| `conflicting_evidence` | Conflicting evidence | Sources make incompatible claims about the same point. Attribute and cite each account. |
| `not_found` | Not found in this file | A completed search in this revision did not locate the requested evidence. Identify what was sought. |
| `incomplete_search` | Incomplete search | A limit or failure interrupted the investigation. Identify an unchecked source or lead when known. |

In the water-damage example, finding the recommendation but no test result is
a completed search with a gap. An interrupted search that never opened the
engineering report would be incomplete. [Compare the worked answers](../examples/water-damage-handover.md#example-checklist-at-r3).

[Project home](../index.md) · [Evidence and citations](evidence-and-citations.md) · [Research workflow](../workflows/agentic-research.md)
