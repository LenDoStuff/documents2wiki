# Claim wiki purpose

Maintain one wiki per property claim. Help the handler taking over the file see what happened, who was involved, and what evidence they still need to decide whether to pursue subrogation.

## Wiki folder structure

```text
wiki/
  index.md
  file-overview.md
  chronology.md
  causation.md
  action-plan.md
  documents/
    D-01-v1.md
```

Link the four claim pages and one cited summary per source version from `index.md`. For example, `documents/D-01-v1.md` summarizes the claim’s original `originals/D-01-v1.pdf`.

- **File Overview** — Summarize the loss and material developments. List each document with its receipt date and a link to its summary.
- **Claim Chronology** — Order events by when they happened. Label approximate, unknown, or disputed dates.
- **Claim Causation** — Attribute each observation or possible cause to its source. Preserve the author’s degree of certainty and any competing accounts.
- **Claims Handler Action Plan** — List open questions, requested actions, and documented results. A recommended test stays open until a source records its outcome.

## When a document arrives

For the first build, summarize every source already on file and account for its material facts on the four pages. On later additions, summarize the new source version, list it once, and amend each entry its evidence changes. A routine receipt may need only its summary and links from the index and inventory.

Read the original page before adding or amending a material statement. Cite the document version and physical PDF page, counting the first page as 1. For an explicit correction, record the new value and cite both the correction and the earlier record. When accounts conflict, attribute and cite each one.
